import './styles/global.css';
import './styles/theme.css';

import { ContainerHead } from './components/ContainerHead';
import { Container } from './components/Container';

export function App() {
  return (
    <>
      <ContainerHead>
        <label>Testando</label>
      </ContainerHead>

      <Container>
        <label>Testando</label>
      </Container>
    </>
  );
}
